import MainInfo from "../sections/item/MainInfo";
import Nav from "../sections/item/Nav";


function Item() {

  return (
    <div>
      <h1>jhdjerhgkjlhsasjfkhdjkfhkjdhfkjdff</h1>
      <Nav />
      <MainInfo />
    </div>
  );
}

export default Item;
