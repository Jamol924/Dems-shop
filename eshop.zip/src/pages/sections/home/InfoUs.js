import React from "react";
import Info from "../../../components/common/Info";

const InfoUs = () => {
  return <Info />;
};

export default InfoUs;
