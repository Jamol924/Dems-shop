import React from "react";
import StatsInfo from "../../../components/common/StatsInfo";

const Statistics = () => {
  return <StatsInfo />;
};

export default Statistics;
